#ifndef LSYS_H
#define LSYS_H

#include <GLGraphics/GLHeader.h>

GLuint make_tree (int&);

#endif // LSYS_H
