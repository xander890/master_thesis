#ifndef __CGLA_VEC4F_H__
#define __CGLA_VEC4F_H__

#include "Vec3f.h"
#include "ArithVec4Float.h"

namespace CGLA {

	/** \brief A four dimensional floating point vector. 

			This class is also used (via typedef) for
			homogeneous vectors.
	*/

	class Vec4f: public ArithVec4Float<float,Vec4f>
	{
	public:
  
		/// Construct a (0,0,0,0) homogenous Vector
		Vec4f(): ArithVec4Float<float,Vec4f>(0,0,0,0.0) {}

		/// Construct a (0,0,0,0) homogenous Vector
		explicit Vec4f(float _a): ArithVec4Float<float,Vec4f>(_a,_a,_a,_a) {}

		/// Construct a 4D vector
		Vec4f(float _a, float _b, float _c, float _d): 
			ArithVec4Float<float,Vec4f>(_a,_b,_c,_d) {}

		/// Construct a homogenous vector (a,b,c,1)
		Vec4f(float _a, float _b, float _c): 
			ArithVec4Float<float,Vec4f>(_a,_b,_c,1.0) {}

		/// Construct a homogenous vector from a non-homogenous.
		explicit Vec4f(const Vec3f& v): 
			ArithVec4Float<float,Vec4f>(v[0],v[1],v[2],1.0) {}

		/// Construct a homogenous vector from a non-homogenous.
		explicit Vec4f(const Vec3f& v,float _d): 
			ArithVec4Float<float,Vec4f>(v[0],v[1],v[2],_d) {}

		operator Vec3f() const
		{
			float k = 1.0f/(*this)[3];
			return Vec3f((*this)[0]*k,(*this)[1]*k,(*this)[2]*k);
		}
	};
}
#endif

