#ifndef __CGLA_QUATERNION_H__
#define __CGLA_QUATERNION_H__

#include "Quatf.h"

namespace CGLA {

	typedef Quatf Quaternion;
}
#endif
