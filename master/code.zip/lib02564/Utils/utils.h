#ifndef UTILS_H
#define UTILS_H

class utils
{
public:
    utils();
};

#endif // UTILS_H
