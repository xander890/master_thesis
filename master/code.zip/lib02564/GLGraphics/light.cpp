#include "light.h"

namespace GLGraphics
{

}
