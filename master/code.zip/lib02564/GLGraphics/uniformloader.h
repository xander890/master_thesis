#ifndef UNIFORMLOADER_H
#define UNIFORMLOADER_H

namespace GLGraphics
{
    class UniformLoader
    {
    public:
        void loadUniforms();
    };
}

#endif // UNIFORMLOADER_H
