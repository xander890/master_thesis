#include "imagetexture.h"

using namespace Mesh;

void ImageTexture::bindImage(int activeImage)
{

}
